package com.example.SpringBoot.InsuranceManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceManagementPlatformProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceManagementPlatformProjectApplication.class, args);
	}

}
